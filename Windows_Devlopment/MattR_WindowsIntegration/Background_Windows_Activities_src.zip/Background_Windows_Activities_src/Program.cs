﻿// See https://aka.ms/new-console-template for more information
using Background_Windows_Activities;
using System.Diagnostics;
using System.Data.SQLite;
using System.Text;

string databaseFile = "myDatabase.sqlite";
string csvFile = "myDatabase.csv";

if (!File.Exists(databaseFile))
{
    SQLiteConnection.CreateFile(databaseFile);
}

if (!File.Exists(csvFile))
{
    string[] columnHeadings = {  "TIMESTAMP", "EVENT_NAME", "EVENT_ID", "PARAMETERS", "ACTIVITY" };
    StringBuilder csvData= new StringBuilder(); 
    csvData.AppendLine(string.Join(",", columnHeadings));
    File.WriteAllText(csvFile, csvData.ToString());
}



WinOpen winOpen = new WinOpen();
WinOpenSubscriber winOpensubscriber = new WinOpenSubscriber(winOpen);
WinClosed winClosed = new WinClosed(); 
WinClosedSubscriber winClosedSubscriber = new WinClosedSubscriber(winClosed);

Process[] currentProcesses= Process.GetProcesses();
List<Process> currentWins = new List<Process>();
List<Process> pastWins = new List<Process>();

IntPtr hWind=IntPtr.Zero;

foreach (Process process in currentProcesses)
{
    hWind = process.MainWindowHandle;

    if (hWind != IntPtr.Zero)
    {
        currentWins.Add(process);
        pastWins.Add(process);
    }
}
hWind = IntPtr.Zero;

string exitKey = "a";

while (true)
{
    /////////////////////////////////////////////
   /* Console.WriteLine("PAST WINDOWS");
    foreach (Process p in pastWins)
    {
        Console.WriteLine(p.ProcessName);
    }

    /////////////////////////////////////////////
    ///*/

    if (pastWins.Count < currentWins.Count)
    {  
        pastWins=winOpen.checkNewWindowOpen(pastWins, currentWins, currentProcesses);
    }else if (pastWins.Count > currentWins.Count)
    {
        pastWins =winClosed.CheckWindowClosed(pastWins, currentWins, currentProcesses);
    }

    Array.Clear(currentProcesses,0,currentProcesses.Length);
    currentProcesses = Process.GetProcesses();

    currentWins.Clear();

    //Console.WriteLine("CURRENT WINDOWS");
    foreach (Process process in currentProcesses)
    {
        hWind = process.MainWindowHandle;

        if (hWind != IntPtr.Zero)
        {
            currentWins.Add(process);
           // Console.WriteLine(process.ProcessName);
        }
    }
    hWind = IntPtr.Zero;
    //exitKey = Console.ReadLine();
}

