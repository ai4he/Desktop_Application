﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Background_Windows_Activities
{
    internal class ProcessComparer: IEqualityComparer<Process>
    {
            public bool Equals(Process x, Process y)
            {
                return x.Id == y.Id;
            }

            public int GetHashCode(Process obj)
            {
                return obj.Id.GetHashCode();
            }
    }
}
