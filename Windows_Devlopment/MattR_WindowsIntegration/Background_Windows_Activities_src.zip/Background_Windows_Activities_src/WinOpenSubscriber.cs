﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Background_Windows_Activities
{
    internal class WinOpenSubscriber
    {
        public WinOpenSubscriber(WinOpen winOpen) 
        {
            winOpen.WindowOpen += HandleWindowOpen;
        }

        void HandleWindowOpen(object sender, CustomEventArgs e)
        {
            long time= DateTime.Now.Ticks;
            int evntId = 0;
            string evntName = "WindowOpen";
            
            EvntObj evntObj = new EvntObj(time,evntId,evntName,e);
            evntObj.ConEvent();
            evntObj.InsertObjIntoSQLite();
        }
    }
}
