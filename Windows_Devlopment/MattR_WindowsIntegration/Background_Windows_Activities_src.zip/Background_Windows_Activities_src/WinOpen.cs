﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Background_Windows_Activities
{
    internal class WinOpen
    {
        public delegate void WindowOpenHandler(object sender, CustomEventArgs e);

        public event EventHandler<CustomEventArgs>? WindowOpen;

        public List<Process> checkNewWindowOpen(List<Process> pastWins, List<Process> currentWins, Process[] currentProcesses)
        { 
            //Console.WriteLine("Past Windows Count:"+pastWins.Count);
            //Console.WriteLine("Current Windows Count:" + currentWins.Count);

            ProcessComparer comparer = new ProcessComparer();

            foreach (Process p in currentWins)
            {
                Console.WriteLine(p.Id);

                if (!pastWins.Contains(p,comparer))
                {
                    string name = p.ProcessName;
                    string id = p.Id.ToString();
                    string param = "{name:" + name + ",id:" + id + "}";

                    OnWindowOpen(new CustomEventArgs(param));
                    Thread.Sleep(1000);
                }    
            }

            pastWins.Clear();
            IntPtr hWind = IntPtr.Zero;

            foreach (Process process in currentProcesses)
            {
                hWind = process.MainWindowHandle;

                if (hWind != IntPtr.Zero)
                {
                    pastWins.Add(process);
                    // Console.WriteLine(process.ProcessName);
                }
            }
            return pastWins;
        }

        protected virtual void OnWindowOpen(CustomEventArgs e)
        {
            EventHandler<CustomEventArgs>? windowOpen = WindowOpen;

            if (windowOpen != null)
            {
                windowOpen?.Invoke(this, e);
            }
        }
    }
}
