﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Background_Windows_Activities
{
    internal class CustomEventArgs: EventArgs
    {
        public CustomEventArgs(string jsonParams)
        {
            JsonParams = jsonParams;
        }

        public string getJsonParams()
        {
            return JsonParams;
        }

        private string JsonParams;
    }
}
