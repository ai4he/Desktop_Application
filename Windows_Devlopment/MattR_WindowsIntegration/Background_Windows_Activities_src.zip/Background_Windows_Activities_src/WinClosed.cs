﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Background_Windows_Activities
{
    internal class WinClosed
    {
        public delegate void WindowClosedHandler(object sender, CustomEventArgs e);

        public event EventHandler<CustomEventArgs>? WindowClosed;

        public List<Process> CheckWindowClosed(List<Process> pastWins, List<Process> currentWins, Process[] currentProcesses)
        {
            ProcessComparer comparer=new ProcessComparer();

            foreach (Process p in pastWins)
            {
                if (!currentWins.Contains(p,comparer))
                {
                    string name = p.ProcessName;
                    string id = p.Id.ToString();
                    string param = "{name:" + name + ",id:" + id + "}";

                    OnWindowClosed(new CustomEventArgs(param));
                    Thread.Sleep(1000);
                }
            }

            pastWins.Clear();
            IntPtr hWind = IntPtr.Zero;

            foreach (Process process in currentProcesses)
            {
                hWind = process.MainWindowHandle;

                if (hWind != IntPtr.Zero)
                {
                    pastWins.Add(process);
                    // Console.WriteLine(process.ProcessName);
                }
            }

            return pastWins;
        }

        protected virtual void OnWindowClosed(CustomEventArgs e)
        {
            EventHandler<CustomEventArgs>? windowClosed = WindowClosed;

            if (windowClosed != null)
            {
                windowClosed?.Invoke(this, e);
            }
        }

    }
}
