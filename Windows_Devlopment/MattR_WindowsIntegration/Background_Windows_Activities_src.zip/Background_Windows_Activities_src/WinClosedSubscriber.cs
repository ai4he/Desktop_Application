﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Background_Windows_Activities
{
    internal class WinClosedSubscriber
    {
        public WinClosedSubscriber(WinClosed winClosed)
        {
            winClosed.WindowClosed += HandleWindowClosed;
        }

        void HandleWindowClosed(object sender, CustomEventArgs e)
        {
            long time = DateTime.Now.Ticks;
            int evntId = 1;
            string evntName = "WindowClosed";

            EvntObj evntObj = new EvntObj(time, evntId, evntName, e);
            evntObj.ConEvent();
            evntObj.InsertObjIntoSQLite();
        }
    }
}
