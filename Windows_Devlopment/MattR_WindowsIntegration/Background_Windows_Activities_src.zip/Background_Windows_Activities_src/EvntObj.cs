﻿using CsvHelper;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SQLite;
using System.Diagnostics;
using System.Formats.Asn1;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Background_Windows_Activities
{
    internal class EvntObj
    {
        public EvntObj(long time, int evnt_id, string evnt_name, CustomEventArgs param) 
        {
           // Id++;
            Time = time;
            EvntId = evnt_id;
            EvntName=evnt_name;
            Parameters=param;
        }


        public void ConEvent()
        {
            Console.WriteLine(Parameters.getJsonParams());
        }

        public void InsertObjIntoSQLite()
        {
            // Step 1: Download and install the SQLite ADO.NET provider

            // Step 2: Create an SQLite database file
            string databaseFile = "myDatabase.sqlite";
            //  SQLiteConnection.CreateFile(databaseFile);

            // Step 3: Connect to the SQLite database
            string connectionString = "Data Source=" + databaseFile;
            SQLiteConnection connection = new SQLiteConnection(connectionString);
            connection.Open();

            // Step 4: Execute SQL statements
            string createTableQuery = "CREATE TABLE IF NOT EXISTS BackgroundEvents (Id INTEGER PRIMARY KEY AUTOINCREMENT, Timestamp BIGINT NOT NULL, EventId INTEGER NOT NULL, EventName TEXT NOT NULL, Json TEXT NOT NULL, Activity TEXT NULL)";
            SQLiteCommand createTableCommand = new SQLiteCommand(createTableQuery, connection);
            createTableCommand.ExecuteNonQuery();

            string insertQuery = "INSERT INTO BackgroundEvents (Timestamp, EventId, EventName, Json) VALUES (@param2,@param3,@param4,@param5)";
            SQLiteCommand insertCommand = new SQLiteCommand(insertQuery, connection);
            // insertCommand.Parameters.AddWithValue("@param1",Id);
            insertCommand.Parameters.AddWithValue("@param2", Time);
            insertCommand.Parameters.AddWithValue("@param3", EvntId);
            insertCommand.Parameters.AddWithValue("@param4", EvntName);
            insertCommand.Parameters.AddWithValue("@param5", Parameters.getJsonParams());
            insertCommand.ExecuteNonQuery();

            using(var writer=new StreamWriter("myDatabase.csv", true)) 
            {
                writer.Write(Time.ToString());
                writer.Write(',');
                writer.Write(EvntName);
                writer.Write(',');
                writer.Write(EvntId);
                writer.Write(',');
                string jsonString = JsonConvert.SerializeObject(Parameters.getJsonParams());
                writer.Write(jsonString); 
                writer.WriteLine();
            }

            connection.Close();

        }
       // private static int Id=-1;
        private long Time;
        private int EvntId;
        private string EvntName;
        private CustomEventArgs Parameters;
    }
}
