let data=window.barData.createBarData();

let dayObject=[]
let weekObject=[];
let monthObject=[];

// Object.keys(data).map(function(key,index){
//   if (index<5){
//     Object.assign(dayObject, data[index]);
//   }else if (index>4 & index <10){
//     Object.assign(weekObject, data[index]);
//   }else if (index>9){
//     Object.assign(monthObject, data[index]);
//   }
// })
for (var i=0; i<data.length; i++){
  if (i<5){
    dayObject.push(data[i]);
  }else if (i>4 & i<10){
    weekObject.push(data[i]);
  }else if (i>9){
    monthObject.push(data[i]);
  }
}

  const margin = { top: 20, right: 20, bottom: 30, left: 100 };
  const width = 500 - margin.left - margin.right;
  const height = 300 - margin.top - margin.bottom;

  const svgDay = d3.select("#day")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

  const svgWeek = d3.select("#week")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

  const svgMonth = d3.select("#month")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

function createBarGraph(svgId, obj, margin,width, height){

  const x = d3.scaleLinear()
    .domain([0, d3.max(obj, d => d.value)])
    .range([0, width]);

  const y = d3.scaleBand()
    .domain(obj.map(d => d.name))
    .range([0, height])
    .padding(0.1);

  const xAxis = d3.axisBottom(x);
  const yAxis = d3.axisLeft(y);

  svgId.append("g")
    .attr("class", "x axis")
    .attr("transform", "translate(0," + height + ")")
    .call(xAxis);

svgId.append("g")
    .attr("class", "y axis")
    .call(yAxis);

    svgId.selectAll(".bar")
        .data(obj)
        .enter().append("rect")
        .attr("class", "bar")
        .attr("x", 0)
        .attr("y", d => y(d.name))
        .attr("width", d => x(d.value))
        .attr("height", y.bandwidth());

}

createBarGraph(svgDay,dayObject, margin, width, height);
createBarGraph(svgWeek,weekObject, margin, width,height);
createBarGraph(svgMonth, monthObject,margin,width,height);