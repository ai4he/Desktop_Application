import { Chart } from "chart.js";

export function barChart(labels,data, str){

    const myChart = new Chart(str, {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [{
            label: 'My Dataset',
            data: data,
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }]
          }
        }
      });

}

window.barChart=barChart
